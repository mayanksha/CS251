INSERT INTO Bank_details VALUES ("msharma@iitk.ac.in", "Mayank Sharma", "B-40 Kumbha", 9461240034, 34555, "lsdfjl") ;
INSERT INTO Bank_details VALUES ("msharma@iitk.ac.in", "Mayank Sharma", "B-40 Kumbha", 9461240034, 34555, "sldjljlsdfjl") ;
