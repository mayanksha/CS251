CREATE TABLE Bank_details (
	email 		text,
	name		text,
	address		text,
	phone		int,
	acc 		int,
	pass 		text
);
