#include <common.h>
int do_graphics(void)
{
   return do_math();
}
